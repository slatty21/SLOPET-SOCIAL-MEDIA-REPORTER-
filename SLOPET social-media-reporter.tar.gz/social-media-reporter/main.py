import os
import random
import time
import sys
from colorama import Fore, Style, init
from utils.license_manager import LicenseManager
from platforms.instagram import InstagramReporter
from platforms.tiktok import TikTokReporter
from platforms.x import XReporter
from platforms.youtube import YouTubeReporter
from platforms.facebook import FacebookReporter

init(autoreset=True)

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def display_menu():
    clear_screen()
    logo_lines = [
        "   ███████╗ ██╗      ██████╗ ██████╗ ███████╗████████╗",
        "   ██╔════╝ ██║     ██╔═══██╗██╔══██╗██╔════╝╚══██╔══╝",
        "   ███████╗ ██║     ██║   ██║██████╔╝███████╗   ██║   ",
        "   ╚════██║ ██║     ██║   ██║██╔═══╝ ╚════██║   ██║   ",
        "   ███████║ ███████╗╚██████╔╝██║     ███████║   ██║   ",
        "   ╚══════╝╚══════╝ ╚═════╝ ╚═╝     ╚══════╝   ╚═╝    ",
    ]

    colors = [Fore.GREEN, Fore.CYAN, Fore.MAGENTA, Fore.BLUE, Fore.YELLOW, Fore.RED]  # More colors for randomization

    for line in logo_lines:
        colored_line = "".join(random.choice(colors) + ch for ch in line)
        sys.stdout.write(colored_line + Style.RESET_ALL + "\n")
        sys.stdout.flush()
        time.sleep(0.05)

    print(Fore.YELLOW + Style.BRIGHT + "\n" + "═" * 75)
    print(Fore.YELLOW + Style.BRIGHT + "    🚀 ADVANCED SOCIAL MEDIA MASS REPORTING TOOL 🚀")
    print(Fore.YELLOW + Style.BRIGHT + "═" * 75)
    print(Fore.WHITE + Style.BRIGHT + "\n┌─────────────────────────────────────────────────────────────────────┐")
    print(Fore.WHITE + Style.BRIGHT + "│                    SELECT A PLATFORM TO MASS REPORT                │")
    print(Fore.WHITE + Style.BRIGHT + "└─────────────────────────────────────────────────────────────────────┘")
    print(Fore.GREEN + Style.BRIGHT + "\n  📱 1. Instagram")
    print(Fore.RED + Style.BRIGHT + "  🎵 2. TikTok")
    print(Fore.BLUE + Style.BRIGHT + "  🐦 3. X (Twitter)")
    print(Fore.RED + Style.BRIGHT + "  📺 4. YouTube")
    print(Fore.BLUE + Style.BRIGHT + "  📘 5. Facebook")
    print(Fore.WHITE + Style.BRIGHT + "\n  ❌ 0. Exit")
    print(Fore.CYAN + Style.BRIGHT + "\n" + "─" * 75)

def main():
    license_manager = LicenseManager()

    while True:
        display_menu()
        choice = input(Fore.YELLOW + Style.BRIGHT + "\n➤ Enter your choice: ")

        if choice == "0":
            print(Fore.RED + Style.BRIGHT + "\n🔴 Exiting tool. Goodbye!")
            break
        elif choice == "1":
            platform_name = "Instagram"
            reporter = InstagramReporter()
        elif choice == "2":
            platform_name = "TikTok"
            reporter = TikTokReporter()
        elif choice == "3":
            platform_name = "X (Twitter)"
            reporter = XReporter()
        elif choice == "4":
            platform_name = "YouTube"
            reporter = YouTubeReporter()
        elif choice == "5":
            platform_name = "Facebook"
            reporter = FacebookReporter()
        else:
            print(Fore.RED + Style.BRIGHT + "\n❌ Invalid choice. Please try again.")
            input(Fore.MAGENTA + Style.BRIGHT + "Press Enter to continue...")
            continue

        if not license_manager.check_license():
            print(Fore.RED + Style.BRIGHT + "\n🔒 Full mass reporting features require a license.")
            print(Fore.YELLOW + Style.BRIGHT + "💬 Please contact " + Fore.CYAN + Style.BRIGHT + "@SMRKEYBOT" + Fore.YELLOW + Style.BRIGHT + " on Telegram to purchase a license.")
            print(Fore.GREEN + Style.BRIGHT + "🎯 You can still perform a single report as a demo.")
            
            target = input(Fore.BLUE + Style.BRIGHT + f"\n🎯 Enter target for {platform_name} (e.g., username or link): ")
            reason = input(Fore.BLUE + Style.BRIGHT + "📝 Enter report reason (e.g., spam, impersonation): ")
            
            if reporter.report(target, reason):
                print(Fore.GREEN + Style.BRIGHT + "✅ Demo report sent successfully!")
            else:
                print(Fore.RED + Style.BRIGHT + "❌ Demo report failed.")
            
            activate_choice = input(Fore.BLUE + Style.BRIGHT + "\n🔑 Do you have a license key to activate? (y/n): ").lower()
            if activate_choice == "y":
                key = input(Fore.BLUE + Style.BRIGHT + "🔐 Enter your license key: ")
                if license_manager.activate_license(key):
                    print(Fore.GREEN + Style.BRIGHT + "✅ License activated successfully!")
                else:
                    print(Fore.RED + Style.BRIGHT + "❌ Invalid license key.")
            else:
                input(Fore.MAGENTA + Style.BRIGHT + "Press Enter to return to main menu...")
                continue
        else:
            print(Fore.GREEN + Style.BRIGHT + "\n🔓 License activated! Full features unlocked.")
            target = input(Fore.BLUE + Style.BRIGHT + f"\n🎯 Enter target for {platform_name} (e.g., username or link): ")
            reason = input(Fore.BLUE + Style.BRIGHT + "📝 Enter report reason (e.g., spam, impersonation): ")
            num_reports = input(Fore.BLUE + Style.BRIGHT + "🔢 Enter number of reports to send (e.g., 100): ")
            
            try:
                num_reports = int(num_reports)
                print(Fore.YELLOW + Style.BRIGHT + f"\n🚀 Starting mass reporting to {target} on {platform_name}...")
                for i in range(num_reports):
                    print(Fore.CYAN + f"📤 Sending report {i+1}/{num_reports}...")
                    reporter.report(target, reason)
                print(Fore.GREEN + Style.BRIGHT + f"\n🎉 Successfully sent {num_reports} reports to {target} on {platform_name}!")
            except ValueError:
                print(Fore.RED + Style.BRIGHT + "❌ Invalid number of reports. Please enter a number.")
            except Exception as e:
                print(Fore.RED + Style.BRIGHT + f"💥 An error occurred during mass reporting: {e}")

        input(Fore.MAGENTA + Style.BRIGHT + "\nPress Enter to continue...")

if __name__ == "__main__":
    main()


